

DIRECTIONS = {
    'N': 1,
    'E': 2,
    'S': 3,
    'W': 4
}

VALID_COMMANDS = {
    'L',
    'R',
    'M'
}

